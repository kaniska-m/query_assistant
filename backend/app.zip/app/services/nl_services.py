import os
from groq import Groq
from app.schemas.nl_schema import PRIMARY_TABLES
from app.services.prompt_builder import build_primary_schema, build_system_prompt

client = Groq(api_key=os.environ.get("GROQ_API_KEY"))

_schema_cache = None


def get_cached_schema() -> str:
    global _schema_cache
    if _schema_cache is None:
        _schema_cache = build_primary_schema(PRIMARY_TABLES)
        print(f"[NL] Schema cached for: {PRIMARY_TABLES}")
    return _schema_cache


def nl_to_sql(prompt: str) -> str:
    schema = get_cached_schema()

    if not schema.strip():
        raise Exception("Schema could not be loaded. Check DB connection.")

    system_prompt = build_system_prompt(schema)

    print(f"[NL] Prompt: {prompt}")

    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt},
        ],
        temperature=0.1,
        max_tokens=768,
    )

    sql = response.choices[0].message.content.strip()
    print(f"[NL] Raw: {sql}")

    # Strip accidental markdown fences
    if "```" in sql:
        parts = sql.split("```")
        sql = parts[1] if len(parts) > 1 else parts[0]
        if sql.lower().startswith("sql"):
            sql = sql[3:]

    sql = sql.strip().rstrip(";")
    print(f"[NL] Final SQL: {sql}")
    return sql