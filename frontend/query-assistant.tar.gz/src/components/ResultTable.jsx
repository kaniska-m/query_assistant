export default function ResultTable({ columns = [], data = [], execTime, rowCount }) {
  if (!columns.length) return null;

  return (
    <div>
      {(execTime || rowCount !== undefined) && (
        <div className="exec-meta">
          {rowCount !== undefined && <span className="count">↳ {rowCount} row{rowCount !== 1 ? 's' : ''}</span>}
          {execTime && <span className="time">⏱ {execTime}</span>}
        </div>
      )}
      <div className="result-table-wrap">
        <table className="result-table">
          <thead>
            <tr>
              {columns.map((col) => (
                <th key={col}>{col}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.length === 0 ? (
              <tr>
                <td colSpan={columns.length} style={{ textAlign: 'center', padding: '24px', color: 'var(--text-2)' }}>
                  No rows returned
                </td>
              </tr>
            ) : (
              data.map((row, i) => (
                <tr key={i}>
                  {columns.map((col) => (
                    <td key={col} title={String(row[col] ?? '')}>
                      {row[col] === null || row[col] === undefined ? (
                        <span style={{ color: 'var(--text-2)' }}>NULL</span>
                      ) : (
                        String(row[col])
                      )}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
